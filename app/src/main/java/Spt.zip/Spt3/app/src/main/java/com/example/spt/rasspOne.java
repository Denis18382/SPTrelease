package com.example.spt;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class rasspOne extends AppCompatActivity {


    Button button47, button46, button44;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_rassp_one);
        button47 =(Button)findViewById(R.id.button47);





        button47.setOnClickListener((v) -> {
            Intent intent = new Intent();
            intent.setClass(rasspOne.this, Main11Activity.class);
            Bundle b =  new Bundle();
            b.putString("class ID", "101");
            intent.putExtras(b);
            startActivity(intent);
    });












    }
    public void back(View v) {
        Intent intent = new Intent(this, MainActivity.class);
        startActivity(intent);
    }


}