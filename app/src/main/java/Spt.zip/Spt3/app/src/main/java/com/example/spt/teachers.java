package com.example.spt;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;

import com.example.spt.teacher.teacher1;
import com.example.spt.teacher.teacher10;
import com.example.spt.teacher.teacher11;
import com.example.spt.teacher.teacher12;
import com.example.spt.teacher.teacher13;
import com.example.spt.teacher.teacher14;
import com.example.spt.teacher.teacher15;
import com.example.spt.teacher.teacher16;
import com.example.spt.teacher.teacher17;
import com.example.spt.teacher.teacher18;
import com.example.spt.teacher.teacher19;
import com.example.spt.teacher.teacher2;
import com.example.spt.teacher.teacher20;
import com.example.spt.teacher.teacher21;
import com.example.spt.teacher.teacher22;
import com.example.spt.teacher.teacher23;
import com.example.spt.teacher.teacher24;
import com.example.spt.teacher.teacher25;
import com.example.spt.teacher.teacher26;
import com.example.spt.teacher.teacher27;
import com.example.spt.teacher.teacher28;
import com.example.spt.teacher.teacher29;
import com.example.spt.teacher.teacher3;
import com.example.spt.teacher.teacher30;
import com.example.spt.teacher.teacher31;
import com.example.spt.teacher.teacher32;
import com.example.spt.teacher.teacher4;
import com.example.spt.teacher.teacher5;
import com.example.spt.teacher.teacher6;
import com.example.spt.teacher.teacher7;
import com.example.spt.teacher.teacher8;
import com.example.spt.teacher.teacher9;

public class teachers extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_teachers);
    }

    public void back(View v) {
        Intent intent = new Intent(this, MainActivity.class);
        startActivity(intent);
    }

   public void t1(View v) {
        Intent intent = new Intent(this, teacher1.class);
        startActivity(intent);
   }
    public void t2(View v) {
        Intent intent = new Intent(this, teacher2.class);
        startActivity(intent);
    }
    public void t3(View v) {
        Intent intent = new Intent(this, teacher3.class);
        startActivity(intent);
    }
    public void t4(View v) {
        Intent intent = new Intent(this, teacher4.class);
        startActivity(intent);
    }
    public void t5(View v) {
        Intent intent = new Intent(this, teacher5.class);
        startActivity(intent);
    }
    public void t6(View v) {
        Intent intent = new Intent(this, teacher6.class);
        startActivity(intent);
    }
    public void t7(View v) {
        Intent intent = new Intent(this, teacher7.class);
        startActivity(intent);
    }
    public void t8(View v) {
        Intent intent = new Intent(this, teacher8.class);
        startActivity(intent);
    }
    public void t9(View v) {
        Intent intent = new Intent(this, teacher9.class);
        startActivity(intent);
    }
    public void t10(View v) {
        Intent intent = new Intent(this, teacher10.class);
        startActivity(intent);
    }
    public void t11(View v) {
        Intent intent = new Intent(this, teacher11.class);
        startActivity(intent);
    }
    public void t12(View v) {
        Intent intent = new Intent(this, teacher12.class);
        startActivity(intent);
    }
    public void t13(View v) {
        Intent intent = new Intent(this, teacher13.class);
        startActivity(intent);
    }
    public void t14(View v) {
        Intent intent = new Intent(this, teacher14.class);
        startActivity(intent);
    }
    public void t15(View v) {
        Intent intent = new Intent(this, teacher15.class);
        startActivity(intent);
    }
    public void t16(View v) {
        Intent intent = new Intent(this, teacher16.class);
        startActivity(intent);
    }
    public void t17(View v) {
        Intent intent = new Intent(this, teacher17.class);
        startActivity(intent);
    }
    public void t18(View v) {
        Intent intent = new Intent(this, teacher18.class);
        startActivity(intent);
    }
    public void t19(View v) {
        Intent intent = new Intent(this, teacher19.class);
        startActivity(intent);
    }
    public void t20(View v) {
        Intent intent = new Intent(this, teacher20.class);
        startActivity(intent);
    }
    public void t21(View v) {
        Intent intent = new Intent(this, teacher21.class);
        startActivity(intent);
    }
    public void t22(View v) {
        Intent intent = new Intent(this, teacher22.class);
        startActivity(intent);
    }
    public void t23(View v) {
        Intent intent = new Intent(this, teacher23.class);
        startActivity(intent);
    }
    public void t24(View v) {
        Intent intent = new Intent(this, teacher24.class);
        startActivity(intent);
    }
    public void t25(View v) {
        Intent intent = new Intent(this, teacher25.class);
        startActivity(intent);
    }
    public void t26(View v) {
        Intent intent = new Intent(this, teacher26.class);
        startActivity(intent);
    }
    public void t27(View v) {
        Intent intent = new Intent(this, teacher27.class);
        startActivity(intent);
    }
    public void t28(View v) {
        Intent intent = new Intent(this, teacher28.class);
        startActivity(intent);
    }
    public void t29(View v) {
        Intent intent = new Intent(this, teacher29.class);
        startActivity(intent);
    }
    public void t30(View v) {
        Intent intent = new Intent(this, teacher30.class);
        startActivity(intent);
    }
    public void t31(View v) {
        Intent intent = new Intent(this, teacher31.class);
        startActivity(intent);
    }
    public void t32(View v) {
        Intent intent = new Intent(this, teacher32.class);
        startActivity(intent);
    }
}